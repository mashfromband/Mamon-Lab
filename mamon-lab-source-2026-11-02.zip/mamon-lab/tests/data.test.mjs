import test from 'node:test';
import assert from 'node:assert/strict';
import DATA from '../dist/data.mjs';
import {evaluate, STAT_META} from '../dist/model.mjs';

const modes={strength:'physical',magic:'magic',defense:'defense',speed:'speed',evasion:'evasion'};
const skills=new Map(DATA.skills.map(skill=>[skill.id,skill]));
const stats=Object.fromEntries(STAT_META.map(({key,max})=>[key,Math.floor(max/2)]));

test('all 38 species have unique names and a supported verified starting attack',()=>{
  assert.equal(DATA.species.length,38);
  assert.equal(new Set(DATA.species.map(species=>species.name)).size,38);
  for(const species of DATA.species){
    assert.ok(species.verifiedAttackSkillIds.includes(species.defaultSkillId));
    for(const id of species.verifiedAttackSkillIds){
      const skill=skills.get(id);
      assert.ok(skill,'unresolved attack for '+species.name+': '+id);
      assert.ok(modes[skill.attackStat]);
      assert.ok(Number.isFinite(evaluate(stats,modes[skill.attackStat]).overall));
    }
  }
});
test('all attack and guide references are HTTPS and no species strength multiplier is invented',()=>{
  for(const skill of DATA.skills){
    assert.equal(new URL(skill.sourceUrl).protocol,'https:');
    assert.ok(skill.nativeSpecies.length>0);
  }
  for(const source of DATA.sources)assert.equal(new URL(source.url).protocol,'https:');
  assert.equal(DATA.evidencePolicy.speciesStrengthMultipliers,null);
  assert.equal(DATA.evidencePolicy.officialFormulaVerified,false);
});
test('unusual dependencies remain distinct from physical and magical attacks',()=>{
  assert.equal(skills.get('cornered_mouse').attackStat,'speed');
  assert.equal(skills.get('matador').attackStat,'evasion');
  assert.equal(skills.get('crush').attackStat,'defense');
  assert.equal(skills.get('deception').attackStat,'magic');
});
