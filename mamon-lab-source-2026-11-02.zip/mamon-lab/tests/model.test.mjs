import test from 'node:test';
import assert from 'node:assert/strict';
import { STAT_META, MODES, evaluate, improvementSuggestions, normalizeStats, validateStats, compare } from '../dist/model.mjs';

const statSet = (ratio) => Object.fromEntries(STAT_META.map(({ key, max }) => [key, Math.round(max * ratio)]));
const modes = Object.keys(MODES);

test('every mode maps all-zero to 0 and every-cap to 100', () => {
  for (const mode of modes) {
    assert.equal(evaluate(statSet(0), mode).overall, 0);
    assert.equal(evaluate(statSet(1), mode).overall, 100);
    assert.equal(evaluate(statSet(1), mode).rawOverall, 100);
  }
});

test('100 is reserved for all eight capped stats, including a secondary attack', () => {
  const capped = statSet(1);
  for (const mode of modes) {
    for (const { key } of STAT_META) {
      const result = evaluate({ ...capped, [key]: capped[key] - 1 }, mode);
      assert.ok(result.rawOverall < 100, `${mode}: ${key}`);
      assert.ok(result.overall < 100, `${mode}: ${key}`);
    }
  }
});

test('HP normalization uses its own 9999 cap', () => {
  const normalized = normalizeStats({ hp: 9999, sp: 999, str: 999, mag: 999, def: 999, hit: 999, eva: 999, spd: 999 });
  assert.ok(Object.values(normalized).every((value) => value === 100));
  assert.equal(normalizeStats({ ...statSet(0), hp: 999 }).hp, 999 / 9999 * 100);
});

test('physical and magical modes are symmetric when attack stats are exchanged', () => {
  const stats = { hp: 4100, sp: 250, str: 820, mag: 115, def: 300, hit: 620, eva: 290, spd: 450 };
  const swapped = { ...stats, str: stats.mag, mag: stats.str };
  assert.equal(evaluate(stats, 'physical').overall, evaluate(swapped, 'magic').overall);
  assert.equal(evaluate(stats, 'physical').rawOverall, evaluate(swapped, 'magic').rawOverall);
  assert.ok(evaluate(stats, 'physical').overall > evaluate(stats, 'magic').overall);
});

test('balanced offense is symmetric and durability mode makes durability matter to offense', () => {
  const stats = { ...statSet(0.3), str: 800, mag: 100, def: 900 };
  assert.equal(evaluate(stats, 'balanced').components.offense, evaluate({ ...stats, str: 100, mag: 800 }, 'balanced').components.offense);
  assert.ok(evaluate(stats, 'defense').components.offense > evaluate(stats, 'balanced').components.offense);
});

test('speed and evasion referenced attacks use the selected attack dependency', () => {
  const stats = { ...statSet(0.3), str: 100, mag: 100, spd: 950, eva: 750 };
  assert.ok(evaluate(stats, 'speed').components.offense > evaluate(stats, 'evasion').components.offense);
  assert.ok(evaluate(stats, 'evasion').components.offense > evaluate(stats, 'physical').components.offense);
  assert.equal(evaluate(stats, 'speed').modeLabel, '速さ参照');
});

test('all valid scores stay bounded; increasing any stat is monotonic for every mode', () => {
  // Deterministic varied configurations include low, high, and strongly uneven builds.
  let seed = 39481;
  const random = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
  const configurations = [statSet(0), statSet(0.5), statSet(1), ...Array.from({ length: 150 }, () => (
    Object.fromEntries(STAT_META.map(({ key, max }) => [key, Math.floor(random() * (max + 1))]))
  ))];
  for (const mode of modes) {
    for (const stats of configurations) {
      const before = evaluate(stats, mode);
      assert.ok(before.rawOverall >= 0 && before.rawOverall <= 100);
      assert.ok(Object.values(before.components).every((value) => value >= 0 && value <= 100));
      for (const { key, max, increment } of STAT_META) {
        if (stats[key] === max) continue;
        const after = evaluate({ ...stats, [key]: Math.min(max, stats[key] + increment) }, mode);
        assert.ok(after.rawOverall > before.rawOverall, `${mode}/${key} must increase: ${JSON.stringify(stats)}`);
        assert.ok(after.overall >= before.overall);
      }
    }
  }
});

test('invalid input is rejected instead of silently becoming a plausible score', () => {
  const stats = statSet(0.5);
  for (const value of [undefined, null, NaN, Infinity, -Infinity, '100', '', true, 1.5]) {
    assert.throws(() => evaluate({ ...stats, sp: value }), TypeError);
  }
  for (const value of [-1, 1000]) assert.throws(() => evaluate({ ...stats, str: value }), RangeError);
  assert.throws(() => evaluate({ ...stats, hp: 10000 }), RangeError);
  assert.throws(() => evaluate(null), TypeError);
  assert.throws(() => evaluate([]), TypeError);
  for (const mode of ['unknown', '__proto__', null, undefined]) {
    if (mode !== undefined) assert.throws(() => evaluate(stats, mode), RangeError);
  }
  assert.equal(validateStats(stats), true);
});

test('suggestions match actual recomputation, sort by improvement and respect caps', () => {
  const stats = { hp: 9960, sp: 100, str: 997, mag: 220, def: 560, hit: 250, eva: 999, spd: 250 };
  const suggestions = improvementSuggestions(stats, 'physical');
  assert.equal(suggestions.length, 7);
  assert.equal(suggestions.find(({ stat }) => stat === 'hp').increment, 39);
  assert.equal(suggestions.find(({ stat }) => stat === 'str').increment, 2);
  assert.ok(!suggestions.some(({ stat }) => stat === 'eva'));
  suggestions.forEach((suggestion, i) => {
    assert.ok(suggestion.rawGain > 0);
    if (i > 0) assert.ok(suggestions[i - 1].rawGain >= suggestion.rawGain);
    const actual = evaluate({ ...stats, [suggestion.stat]: suggestion.to }, 'physical');
    assert.equal(actual.overall, suggestion.newScore);
    assert.equal(actual.rawOverall - evaluate(stats, 'physical').rawOverall, suggestion.rawGain);
  });
  assert.deepEqual(improvementSuggestions(statSet(1), 'physical'), []);
});

test('secondary attack is a modest contributor, while missing hit and SP are recognized', () => {
  const stats = { ...statSet(0.7), hit: 30, sp: 20 };
  const result = evaluate(stats, 'physical');
  assert.deepEqual(new Set(result.weaknesses.map(({ key }) => key)), new Set(['accuracy', 'resource']));
  const suggestions = improvementSuggestions(stats, 'physical');
  const strGain = suggestions.find(({ stat }) => stat === 'str').rawGain;
  const magGain = suggestions.find(({ stat }) => stat === 'mag').rawGain;
  assert.ok(strGain > 8 * magGain);
  assert.equal(evaluate(statSet(1)).weaknesses.length, 0);
  assert.equal(evaluate(statSet(0)).strengths.length, 0);
});

test('comparison is symmetric and evaluation never mutates the caller inputs', () => {
  const a = Object.freeze(statSet(0.25));
  const b = Object.freeze(statSet(0.65));
  const before = JSON.stringify(a);
  const forward = compare(a, b);
  const backward = compare(b, a);
  assert.equal(forward.delta, -backward.delta);
  assert.equal(forward.sameMode, true);
  assert.equal(compare(a, b, 'physical', 'magic').sameMode, false);
  improvementSuggestions(a);
  assert.equal(JSON.stringify(a), before);
});
