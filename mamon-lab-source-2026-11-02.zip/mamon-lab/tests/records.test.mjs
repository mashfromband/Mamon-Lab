import test from 'node:test';
import assert from 'node:assert/strict';
import { cleanDraft, cleanRecord } from '../dist/records.mjs';

const validRecord = () => ({
  species: 'レオルフ',
  mode: 'physical',
  moveId: 'blade',
  stats: { hp: 4800, sp: 320, str: 680, mag: 180, def: 460, hit: 520, eva: 310, spd: 450 },
  isSample: false,
  id: 'existing-record_1',
  title: 'レオルフ・大会前',
  createdAt: '2026-11-01T00:00:00.000Z',
});

test('rejects coerced mode keys before they can enter imported or restored state', () => {
  for (const mode of [['physical'], { mode: 'physical' }, null, true, 1, '__proto__', '', 'unknown']) {
    assert.throws(() => cleanDraft({ ...validRecord(), mode, moveId: 'manual' }), /参照能力が不正/);
    assert.throws(() => cleanRecord({ ...validRecord(), mode, moveId: 'manual' }), /参照能力が不正/);
  }
  for (const mode of ['physical', 'magic', 'defense', 'speed', 'evasion', 'balanced']) {
    assert.equal(cleanRecord({ ...validRecord(), mode, moveId: 'manual' }).mode, mode);
  }
});

test('normalizes a valid exported record and excludes unrecognized fields', () => {
  const source = validRecord();
  source.species = ' レオルフ ';
  source.title = ' 大会前 ';
  source.isSample = true;
  source.extra = 'not retained';
  source.stats.extra = 1000;
  const cleaned = cleanRecord(JSON.parse(JSON.stringify(source)));
  assert.deepEqual(cleaned, {
    ...validRecord(),
    species: 'レオルフ',
    title: '大会前',
    isSample: true,
  });
  assert.equal(cleanDraft({ ...validRecord(), isSample: 'true' }).isSample, false);
});

test('unknown or mismatched moves fall back to the explicitly selected mode', () => {
  assert.equal(cleanDraft({ ...validRecord(), moveId: 'plasma' }).moveId, 'manual');
  assert.equal(cleanDraft({ ...validRecord(), moveId: 'unrecognized' }).moveId, 'manual');
  assert.equal(cleanDraft({ ...validRecord(), moveId: ['blade'] }).moveId, 'manual');
  const magic = cleanDraft({ ...validRecord(), mode: 'magic', moveId: 'plasma' });
  assert.equal(magic.moveId, 'plasma');
  assert.equal(magic.mode, 'magic');
});

test('rejects invalid stats, species names, record names, and dates', () => {
  for (const stats of [null, {}, { ...validRecord().stats, hp: 10000 }, { ...validRecord().stats, sp: 1000 }, { ...validRecord().stats, str: -1 }, { ...validRecord().stats, mag: 2.5 }, { ...validRecord().stats, hit: '300' }]) {
    assert.throws(() => cleanRecord({ ...validRecord(), stats }));
  }
  for (const species of ['', '   ', 'あ'.repeat(41), ['レオルフ'], null]) {
    assert.throws(() => cleanRecord({ ...validRecord(), species }), /マモン名/);
  }
  for (const title of ['', '   ', 'あ'.repeat(61), ['記録'], null]) {
    assert.throws(() => cleanRecord({ ...validRecord(), title }), /記録の名前/);
  }
  for (const createdAt of ['', 'not-a-date', '2026-13-01', null, 123]) {
    assert.throws(() => cleanRecord({ ...validRecord(), createdAt }), /記録の日付/);
  }
});

test('renewal changes the record identity and malformed identities are repaired', () => {
  const source = validRecord();
  const renewed = cleanRecord(source, true);
  assert.notEqual(renewed.id, source.id);
  assert.match(renewed.id, /^[a-zA-Z0-9_-]{1,80}$/);
  assert.deepEqual({ ...renewed, id: source.id }, source);
  assert.match(cleanRecord({ ...source, id: '<invalid>' }).id, /^[a-zA-Z0-9_-]{1,80}$/);
});

test('cleaning records never mutates input, including when a batch rejects', () => {
  const source = validRecord();
  Object.freeze(source.stats);
  Object.freeze(source);
  const snapshot = JSON.stringify(source);
  const result = cleanRecord(source);
  assert.notEqual(result.stats, source.stats);
  result.stats.hp += 100;
  assert.equal(JSON.stringify(source), snapshot);
  const batch = [source, { ...source, mode: ['physical'], moveId: 'manual' }];
  const savedRecords = [source];
  assert.throws(() => {
    const incoming = batch.map((record) => cleanRecord(record, true));
    savedRecords.push(...incoming);
  }, /参照能力が不正/);
  assert.equal(savedRecords.length, 1);
  assert.equal(JSON.stringify(source), snapshot);
});
